import {Product} from "../types";

export type ProductResponse = {
    products:Product[]
}