import {MemoryCartDb} from "../types/memory-cart-db.type";

const db:MemoryCartDb = {}
export default  db