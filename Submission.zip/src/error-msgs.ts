export const NOT_IMPLEMENTED= {err:'not implemented'}
export const INVALID_CREDENTIALS= {err:'credentials not valid'}
export const NOT_AUTHORIZED= {err:'not authorized'}
